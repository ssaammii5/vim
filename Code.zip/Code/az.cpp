#include<bits/stdc++.h>
using namespace std;

#define ll long long

void init_code(){
#ifndef ONLINE_JUDGE
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
#endif
}

int main(void){
	init_code();

	int a,b;
	cin>>a>>b;
	cout<<a<<b;
	return 0;
}
