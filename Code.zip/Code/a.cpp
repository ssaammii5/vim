#include<bits/stdc++.h>
using namespace std;

#define ll long long

void init_code(){
#ifndef ONLINE_JUDGE
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
#endif
}

int main(void){
	init_code();
	
	
	
	return 0;
}
